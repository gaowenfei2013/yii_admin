<?php
Yii::import('gii.generators.form.FormGenerator');

class BFormGenerator extends FormGenerator
{
	public $codeModel='bootstrap.gii.Bform.BFormCode';
}