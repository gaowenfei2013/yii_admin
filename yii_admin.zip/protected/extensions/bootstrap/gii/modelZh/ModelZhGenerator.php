<?php

Yii::import('gii.generators.model.ModelGenerator');
class ModelZhGenerator extends ModelGenerator
{
    public $codeModel = 'bootstrap.gii.modelZh.ModelZhCode';
}