<?php 
 //网站公共配置 return array (
  'date' => 
  array (
    'name' => '日期格式',
    'value' => 'Y-m-d',
    'readOnly' => '1',
  ),
  'dateTime' => 
  array (
    'value' => 'Y-m-d H:i:s ',
    'name' => '日期时间格式',
    'readOnly' => '1',
  ),
  'ceshi' => 
  array (
    'name' => '呵呵',
    'value' => '妈妈们的',
    'readOnly' => '0',
  ),
);