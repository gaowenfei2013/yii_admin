<?php 
 return array(
	'BackendUserUpdateSelfPwd',
	'MenuShow'
);
?>