<?php
return array (
  'template' => 'default',
  'viewPath' => 'admin.views',
);
