<?php
return array (
  'template' => 'zh',
  'baseControllerClass' => 'Controller',
);
